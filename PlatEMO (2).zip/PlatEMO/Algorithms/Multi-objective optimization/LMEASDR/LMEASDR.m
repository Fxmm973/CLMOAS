classdef LMEASDR < ALGORITHM
% <multi/many> <real> <large>

    methods
        function main(Algorithm,Problem)
            %% 参数设置，默认值如下所示
            [nSel,nPer,nCor,type] = Algorithm.ParameterSet(4,6,6,1);

            %% 生成初始化种群
            Population = Problem.Initialization();

            %% 将决策变量分为两类PV与DV，同时对DV进行相关性交互分析继续划分为DV子集
            [PV,DV] = VariableClustering(Problem,Population,nSel,nPer);
            DVSet   = CorrelationAnalysis(Problem,Population,DV,nCor);

            %% 优化
            while Algorithm.NotTerminated(Population)
                % 收敛性优化，次数设定为10次
                for i = 1 : 10
                    drawnow();
                    Population = ConvergenceOptimization(Population,DVSet,type);
                end
                % 多样性（分布性）优化，次数设定为问题的维度次
                for i = 1 : Problem.M
                    drawnow();
                    Population = DistributionOptimization(Population,PV);
                end
            end
        end
    end
end

function Population = ConvergenceOptimization(Population,DVSet,type)
    [N,D] = size(Population.decs);
    Con   = calCon(Population.objs);
    %对每个子组都进行优化
    for i = 1 : length(DVSet)
        %对子组的所有解都产生下一代
        for j = 1 : length(DVSet{i})
            % 选择父代，使用二进制锦标赛方法
            MatingPool = TournamentSelection(2,2*N,Con);
            % 生成子代
            OffDec = Population.decs;
            %使用不同的遗传算子进行后代产生
            if type == 1
                NewDec = OperatorGAhalf(Population(MatingPool).decs,{1,20,D/length(DVSet{i})/2,20});
            elseif type == 2
                NewDec = OperatorDE(Population.decs,Population(MatingPool(1:end/2)).decs,Population(MatingPool(end/2+1:end)).decs,{1,0.5,D/length(DVSet{i})/2,20});
            end
            OffDec(:,DVSet{i}) = NewDec(:,DVSet{i});
            Offspring          = SOLUTION(OffDec);
            % 基于前沿面与原点距离两者来更新后代解
            allCon  = calCon([Population.objs;Offspring.objs]);
            Con     = allCon(1:N);
            newCon  = allCon(N+1:end);
            %如果新解的收敛值比原来小才更新(越小越收敛于pareto前沿面)
            updated = Con > newCon;
            Population(updated) = Offspring(updated);
            Con(updated)        = newCon(updated);
        end
    end
end

function Population = DistributionOptimization(Population,PV)
% 多样性（分布性）优化
    %使用GA算子的遗传算法进行下一代产生
    N            = length(Population);
    OffDec       = Population(TournamentSelection(2,N,calCon(Population.objs))).decs;
    NewDec       = OperatorGA(Population(randi(N,1,N)).decs);
    OffDec(:,PV) = NewDec(:,PV);
    Offspring    = SOLUTION(OffDec);
    %使用环境选择来选择父子代中进入下一种群的解
    Population   = EnvironmentalSelection([Population,Offspring],N);
end

function Con = calCon(PopuObj)
% 计算解的收敛性

    FrontNo = NDSort_SDR(PopuObj,inf);
    Con     = sum(PopuObj,2);
    Con     = FrontNo'*(max(Con)-min(Con)) + Con;
end


