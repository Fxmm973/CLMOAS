function [FrontNo,MaxFNo] = NDSort_SDR(PopObj,nSort)
% 强化非支配排序 (SDR)
    %计算归一化角度大小，使用arcos可以通过边得到角度
    N      = size(PopObj,1);
    %收敛值，即每个维度的目标值的和
    NormP  = sum(PopObj,2);
    cosine = 1 - pdist2(PopObj,PopObj,'cosine');
    cosine(logical(eye(length(cosine)))) = 0;
    Angle  = acos(cosine);
    %使用角度大小求得小生境的大小θ
    temp  = sort(unique(min(Angle,[],2)));
    minA  = temp(min(ceil(N/2),end));
    Theta = max(1,(Angle./minA).^1);
    %进行强化非支配关系的判断
    dominate = false(N);
    for i = 1 : N-1
        for j = i+1 : N
            %如果在同一小生境时i收敛值小于j，则i支配j
            if NormP(i)*Theta(i,j) < NormP(j)
                dominate(i,j) = true;
            %如果不在同一小生境时，则将角度换转再比较收敛值
            elseif NormP(j)*Theta(j,i) < NormP(i)
                dominate(j,i) = true;
            end
        end
    end
    %得到强化非支配关系后进行非支配排序
    FrontNo = inf(1,N);
    MaxFNo  = 0;
    %前沿从0到最大值（即种群大小）循环+1
    while sum(FrontNo~=inf) < min(nSort,N)
        %每一层选取当前所有非支配解
        MaxFNo  = MaxFNo + 1;
        current = ~any(dominate,1) & FrontNo==inf;
        FrontNo(current)    = MaxFNo;
        %去除当前已经选取的解
        dominate(current,:) = false;
    end
end