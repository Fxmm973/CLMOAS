# README

## 环境配置

安装Matlab（推荐r2020b版本或以上），再去Github上下载PlatEMO：https://github.com/BIMK/PlatEMO

## 使用说明

将算法放入PlatEMO的算法文件夹（Multi-Objective Algorithms）中即可

## 注意事项

算法参照的论文一并放在文件夹中，本算法改进的十分不好，效果与原算法几乎一样，只是粗暴的将改进部分嵌入原算法中,本算法数据结果取的为多次分开的结果的最优值，再与原算法平均值相比较，比较取巧，最好能够重新对算法进行改进，达到更好的效果。

## 参考论文

~~~
[1]Zhang X ,  Ye T ,  Ran C , et al. A Decision Variable Clustering-Based Evolutionary Algorithm for Large-Scale Many-Objective Optimization[J]. IEEE Transactions on Evolutionary Computation, 2018, 22(99):97-112.

[2]Tian Y ,  Cheng R ,  Zhang X , et al. A Strengthened Dominance Relation Considering Convergence and Diversity for Evolutionary Many-Objective Optimization[J]. Evolutionary Computation, IEEE Transactions on, 2018.
~~~

