function Population = EnvironmentalSelection(Population,N)
% The environmental selection of distribution optimization in LMEA

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

   %% 强化非支配排序
    PopObj = Population.objs;
    [FrontNo,MaxFNo] = NDSort(PopObj,N);
    Next = FrontNo < MaxFNo;

    %% 选择最后一个可以进入种群的前沿面的解
    Last   = find(FrontNo==MaxFNo);
    %使用截断的方法选择
    Choose = Truncation(Population(Last).objs,N-sum(Next));
    Next(Last(Choose)) = true;
    %下一代种群
    Population = Population(Next);
end

function Choose = Truncation(PopObj,K)
% 使用截断的方法选择

    %% 计算每两个解之间的规范化角度夹角形成的值
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,size(PopObj,1),1))./repmat(fmax-fmin,size(PopObj,1),1);
    Cosine = 1 - pdist2(PopObj,PopObj,'cosine');
    Cosine(logical(eye(length(Cosine)))) = 0;
    
    %% 截断
    % 首先先挑出在边界的极端值，保证多样性
    Choose = false(1,size(PopObj,1)); 
    [~,extreme] = max(PopObj,[],1);
    Choose(extreme) = true;
    % 然后如果没满再通过截断选择剩下的解
    %如果在第k的值可以全部放进去则全选
    if sum(Choose) > K
        selected = find(Choose);
        Choose   = selected(randperm(length(selected),K));
    else
        %只能放一部分则循环去除最小的角度值解
        while sum(Choose) < K
            unSelected = find(~Choose);
            [~,x]      = min(max(Cosine(~Choose,Choose),[],2));
            Choose(unSelected(x)) = true;
        end
    end
end